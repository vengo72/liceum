import pygame
import os
import sys


def load_image(name, colorkey=None):
    fullname = os.path.join('data', name)
    # если файл не существует, то выходим
    if not os.path.isfile(fullname):
        print(f"Файл с изображением '{fullname}' не найден")
        sys.exit()
    image = pygame.image.load(fullname)
    return image


if __name__ == '__main__':
    pygame.init()
    size = width, height = 600, 300
    screen = pygame.display.set_mode(size)
    running = True
    # создадим группу, содержащую все спрайты
    all_sprites = pygame.sprite.Group()

    # создадим спрайт
    sprite = pygame.sprite.Sprite()
    # определим его вид
    sprite.image = load_image("gameover.png")
    # и размеры
    sprite.rect = sprite.image.get_rect()
    sprite.rect.x = -600
    sprite.rect.y = 0
    # добавим спрайт в группу
    all_sprites.add(sprite)
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        if sprite.rect.x != 0:
            sprite.rect.x += 1
        screen.fill((0, 0, 255))
        all_sprites.draw(screen)
        pygame.display.flip()