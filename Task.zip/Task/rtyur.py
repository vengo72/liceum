import os
import random

import pygame


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


size = width, height = 400, 300
screen = pygame.display.set_mode(size)

clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group()
creature_image = load_image("creature.png")


class Creature(pygame.sprite.Sprite):
    image = load_image("creature.png")

    def __init__(self, *group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(*group)
        self.image = Creature.image
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(width)
        self.rect.y = random.randrange(height)


creature = Creature()
creature.rect.x = 10
creature.rect.y = 10
all_sprites.add(creature)

running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                creature.rect.y -= 10
                all_sprites = pygame.sprite.Group()
                all_sprites.add(creature)
            if event.key == pygame.K_RIGHT:
                creature.rect.x += 10
                all_sprites = pygame.sprite.Group()
                all_sprites.add(creature)
            if event.key == pygame.K_DOWN:
                creature.rect.y += 10
                all_sprites = pygame.sprite.Group()
                all_sprites.add(creature)
            if event.key == pygame.K_LEFT:
                creature.rect.x -= 10
                all_sprites = pygame.sprite.Group()
                all_sprites.add(creature)
    screen.fill(pygame.Color("white"))
    all_sprites.draw(screen)
    pygame.display.flip()

pygame.quit()



