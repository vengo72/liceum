import os
import random
import time

import pygame


def load_image(name, color_key=None):
    fullname = os.path.join('data', name)
    try:
        image = pygame.image.load(fullname).convert()
    except pygame.error as message:
        print('Cannot load image:', name)
        raise SystemExit(message)

    if color_key is not None:
        if color_key == -1:
            color_key = image.get_at((0, 0))
        image.set_colorkey(color_key)
    else:
        image = image.convert_alpha()
    return image


size = width, height = 600, 95
screen = pygame.display.set_mode(size)

clock = pygame.time.Clock()
all_sprites = pygame.sprite.Group()
creature_image = load_image("car2.png")


class Car(pygame.sprite.Sprite):
    image = load_image("car2.png")

    def __init__(self, *group):
        # НЕОБХОДИМО вызвать конструктор родительского класса Sprite.
        # Это очень важно!!!
        super().__init__(*group)
        self.image = Car.image
        self.rect = self.image.get_rect()
        self.rect.x = random.randrange(width)
        self.rect.y = random.randrange(height)


car = Car()
car.rect.x = 1
car.rect.y = 10
all_sprites.add(car)
flag = True
running = True
while running:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
    if car.rect.x + 150 == 600:
        car.image = pygame.transform.flip(car.image, True, False)
        flag = False
    elif car.rect.x == 0:
        car.image = pygame.transform.flip(car.image, True, False)
        flag = True
    if flag:
        car.rect.x += 1
    else:
        car.rect.x -= 1
    time.sleep(0.01)
    screen.fill(pygame.Color("white"))
    all_sprites.draw(screen)
    pygame.display.flip()

pygame.quit()



